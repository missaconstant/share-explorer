{"template":"theme.html","title":"Raw","site_root":"../","asset_root":"../../","component_root":"../../components/"}

# Raw

<script>
  $(function() {
    $(".js-demo_carousel").carousel({ theme: "" });
    $(".js-demo_checkbox").checkbox({ theme: "" });
    $(".js-demo_dropdown").dropdown({ theme: "" });
    
    $(".js-demo_number").number({ theme: "" });
    
    $(".js-demo_pagination").pagination({ theme: "" });
    
    $(".js-demo_range").range({ theme: "" });
    $(".js-demo_scrollbar").scrollbar({ theme: "" });
    
    $(".js-demo_tabs").tabs({ theme: "" });
    $(".js-demo_tooltip").tooltip({ theme: "" });
    $(".js-demo_upload").upload({ theme: "" });
  });
</script>